from django import forms
from django.db import models
from django.contrib.auth.models import User

# Create your models here.


# How to make a basic class
class ExampleModel(models.Model):
    """
    Docstring for ExampleModel
    """

    # Name of table
    name = "Example Table"

    # fields
    # CharFields have to be declaired with a default and max_length parameter
    field1 = models.CharField(default="", max_length=100)

    # IntegerFields don't have to be declared with anything, but all fields have an optional blank and null
    field2 = models.IntegerField(blank=True, null=True, default=0)

    # Decimal fields have to have the decimal_places parameter, and max_digits parameter
    # help text can be written for develpers, the String in the beginning (Field 3) is used for forms
    field3 = models.DecimalField(
        "Field 3",
        decimal_places=2,
        max_digits=10,
        default=0,
        help_text="Help text here",
    )

    # Meta class can be made where info about the table itself is stored
    class Meta:
        verbose_name = "Example Model"
        verbose_name_plural = "Example Models"

    # Class specific functions can be declared here as well, functions that use multiple tables are
    # more easily created in a separate "view_utils" file
    def __str__(self):
        return f"This is the Example Table"


class ExampleModel2(models.Model):
    # Foreign Key Fields only have to have the FKey model, and the on_delete parameter
    foreignKeyField = models.ForeignKey(
        "ExampleModel", verbose_name="Example", null=True, on_delete=models.CASCADE
    )


class Status(models.TextChoices):
    OPEN = "open", "Open"
    IN_PROGRESS = "in_progress", "In Progress"
    COMPLETED = "completed", "Completed"


# For now have foreign keys nullable for testing
class TrustFeedback(models.Model):

    class ReturnTimeliness(models.TextChoices):
        ON_TIME = "on_time", "On Time"
        LATE = "late", "Late"

    class ItemCondition(models.TextChoices):
        GOOD = "good", "Good"
        DAMAGED = "damaged", "Damaged"

    transaction = models.ForeignKey(
        "Transaction",
        related_name="transaction",
        on_delete=models.CASCADE,
        null=True,
        blank=True,
    )
    borrower = models.ForeignKey(
        "Profile", related_name="borrower_trust", on_delete=models.CASCADE
    )
    lender = models.ForeignKey(
        "Profile", related_name="lender_trust", on_delete=models.CASCADE
    )
    item_returned = models.BooleanField(default=False)
    return_timeliness = models.CharField(
        max_length=7, choices=ReturnTimeliness.choices, default=ReturnTimeliness.LATE
    )
    item_condition = models.CharField(
        max_length=7, choices=ItemCondition.choices, default=ItemCondition.DAMAGED
    )
    rating_score = models.IntegerField(null=True, blank=True)
    timestamp = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.pk} {self.transaction} {self.lender} {self.rating_score}"


class Transaction(models.Model):

    listing = models.ForeignKey("Listing", on_delete=models.CASCADE)
    lender = models.ForeignKey(
        "Profile", related_name="lending_transaction", on_delete=models.CASCADE
    )
    borrower = models.ForeignKey(
        "Profile", related_name="borrowing_transaction", on_delete=models.CASCADE
    )
    start_date = models.DateTimeField()
    end_date = models.DateTimeField()
    status = models.CharField(
        max_length=12, choices=Status.choices, default=Status.IN_PROGRESS
    )

    def __str__(self):
        return f"{self.pk} {self.listing} {self.lender} {self.borrower}"


# Might change to form.Forms
class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    # f_name = models.CharField(max_length=25, blank=False, null=False)
    # l_name = models.CharField(max_length=25, blank=False, null=False)
    address = models.CharField(max_length=255)
    neighborhood = models.ForeignKey("Neighborhood", on_delete=models.CASCADE)
    photo_url = models.TextField(blank=True, null=True)
    bio = models.TextField(blank=True, null=True)

    class Role(models.TextChoices):
        ADMIN = "admin", "Admin"
        NEIGHBOR = "neighbor", "Neighbor"

    role = models.CharField(max_length=8, choices=Role.choices, default=Role.NEIGHBOR)

    # Trust fields
    trust_rating = models.DecimalField(max_digits=2, decimal_places=1, default=0.0)
    trust_total_transactions = models.IntegerField(default=0)
    trust_returns_missing = models.IntegerField(default=0)
    trust_damaged_count = models.IntegerField(default=0)
    trust_late_count = models.IntegerField(default=0)
    trust_last_updated = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.user.username} ({self.user.first_name})"


class Neighborhood(models.Model):
    name = models.CharField(max_length=100)
    zip = models.CharField(max_length=10)

    def __str__(self):
        return f"{self.pk} {self.name}"


# Adam
class Listing(models.Model):
    class Type(models.TextChoices):
        OFFER = "offer", "Offer"
        REQUEST = "request", "Request"

    EXTRA_STATUS_CHOICES = Status.choices + [
        ("unavailable", "Unavailable"),
    ]

    user = models.ForeignKey(Profile, on_delete=models.CASCADE)
    type = models.CharField(max_length=7, choices=Type.choices, default=Type.REQUEST)
    item = models.ForeignKey("Item", on_delete=models.CASCADE, null=True, blank=True)
    title = models.CharField(max_length=150)
    listing_bio = models.TextField()
    status = models.CharField(
        max_length=15, choices=EXTRA_STATUS_CHOICES, default=Status.OPEN
    )
    start_date = models.DateTimeField()
    end_date = models.DateTimeField()
    image_url = models.TextField()
    neighborhood = models.ForeignKey(Neighborhood, on_delete=models.CASCADE)

    def __str__(self):
        return f"{self.pk}"


class Chat(models.Model):

    class ChatStatus(models.TextChoices):
        ACTIVE = "active", "Active"
        PENDING = "pending", "Pending"
        ARCHIVED = "archived", "Archived"

    transaction = models.ForeignKey(Transaction, on_delete=models.CASCADE)
    chat_creation = models.DateTimeField(auto_now=True)
    status = models.CharField(
        max_length=8, choices=ChatStatus.choices, default=ChatStatus.PENDING
    )

    def __str__(self):
        return f"{self.pk}"


class Message(models.Model):
    chat = models.ForeignKey(Chat, on_delete=models.CASCADE)
    sender = models.ForeignKey(Profile, on_delete=models.CASCADE)
    content = models.TextField()
    timestamp = models.DateTimeField()

    def __str__(self):
        return f"{self.pk}"


# Adam Start
class ItemStatus(models.TextChoices):
    AVAILABLE = "available", "Available"
    TAKEN = "taken", "Taken"


class Item(models.Model):
    name = models.CharField(max_length=255)
    description = models.TextField()
    category = models.CharField(max_length=100)
    status = models.CharField(
        max_length=50, choices=ItemStatus.choices, default=ItemStatus.AVAILABLE
    )
    image = models.ImageField(upload_to="item_images/", blank=True, null=True)

    def __str__(self):
        return f"{self.pk}"


# The items the user has listed
class ItemProfileAssociation(models.Model):
    item = models.ForeignKey(Item, on_delete=models.CASCADE)
    user = models.ForeignKey(Profile, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)


class SavedAssociation(models.Model):
    item = models.ForeignKey(Item, on_delete=models.CASCADE)
    user = models.ForeignKey(Profile, on_delete=models.CASCADE)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ("user", "item")

    def __str__(self):
        return f"{self.user.user.first_name} saved {self.item.name}"


class Events(models.Model):
    title = models.CharField(max_length=255)
    date = models.DateTimeField()
    address = models.CharField(max_length=100)
    description = models.TextField()

    host = models.ForeignKey(Profile, on_delete=models.CASCADE)


class EventProfileAssociation(models.Model):
    event = models.ForeignKey(Events, on_delete=models.CASCADE)
    user = models.ForeignKey(Profile, on_delete=models.CASCADE)


# Adam End
